/* eslint object-curly-newline: ["error", "never"] */
/* eslint max-len: ["error", 160] */
/*
 * This file was generated with makeClass --sdk. Do not edit it.
 */
import { Parameter } from '.';

export type Function = {
  name: string
  type: string
  anonymous?: boolean
  constant?: boolean
  stateMutability?: string
  signature?: string
  encoding: string
  message?: string
  inputs: Parameter[]
  outputs: Parameter[]
}
