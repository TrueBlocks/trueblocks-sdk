/* eslint object-curly-newline: ["error", "never"] */
/* eslint max-len: ["error", 160] */
/*
 * This file was generated with makeClass --sdk. Do not edit it.
 */
import { address, Function, hash } from '.';

export type Abi = {
  address: address
  interfaces: Function[]
  encoding: hash
  type: string
  name: string
  signature: string
}
