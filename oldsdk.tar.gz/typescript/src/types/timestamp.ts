/* eslint object-curly-newline: ["error", "never"] */
/* eslint max-len: ["error", 160] */
/*
 * This file was generated with makeClass --sdk. Do not edit it.
 */
import { blknum, datetime, int64, timestamp } from '.';

export type Timestamp = {
  blockNumber: blknum
  timestamp: timestamp
  date: datetime
  diff: int64
}
