/* eslint object-curly-newline: ["error", "never"] */
/* eslint max-len: ["error", 160] */
/*
 * This file was generated with makeClass --sdk. Do not edit it.
 */
import { address, int64 } from '.';

export type MonitorClean = {
  address: address
  sizeThen: int64
  sizeNow: int64
  dups: int64
}
