/* eslint object-curly-newline: ["error", "never"] */
/* eslint max-len: ["error", 160] */
/*
 * This file was generated with makeClass --sdk. Do not edit it.
 */
import { address, blkrange, uint64 } from '.';

export type ChunkAddress = {
  address: address
  range: blkrange
  offset: uint64
  count: uint64
}
