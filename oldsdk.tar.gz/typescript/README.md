<!-- markdownlint-disable MD033 MD036 MD041 -->
<h1>TrueBlocks / Typescript SDK</h1>

## Introduction

This is the Typescript SDK.
